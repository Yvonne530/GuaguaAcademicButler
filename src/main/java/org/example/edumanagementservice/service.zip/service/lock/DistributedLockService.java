package org.example.edumanagementservice.service.lock;

public class DistributedLockService {
}
