package org.example.edumanagementservice.service;

import org.example.edumanagementservice.dto.CourseRequestDTO;

import java.util.List;

public interface CourseRequestService {
    CourseRequestDTO submitRequest(CourseRequestDTO dto);
    CourseRequestDTO reviewRequest(Long id, boolean approve, String reviewer);
    List<CourseRequestDTO> getRequestsByStudent(Long studentId);
    List<CourseRequestDTO> getPendingRequests();
}
