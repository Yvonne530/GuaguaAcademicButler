package org.example.edumanagementservice.service;

import lombok.RequiredArgsConstructor;
import org.example.edumanagementservice.dto.GradeDTO;
import org.example.edumanagementservice.exception.BusinessException;
import org.example.edumanagementservice.model.Grade;
import org.example.edumanagementservice.model.GradeWeight;
import org.example.edumanagementservice.repository.GradeRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class GradeService {
    private final GradeRepository gradeRepository;

    public void submitGrade(GradeDTO dto) {
        Grade grade = new Grade(null, dto.getStudentId(), dto.getCourseCode(), dto.getSemester(), dto.getScore());
        gradeRepository.save(grade);
    }
    public void setGradeWeights(Long courseId, Long teacherId, List<GradeWeightDTO> weights) {
        // 验证课程是否存在且属于该教师
        Course course = courseRepo.findByIdAndTeacherId(courseId, teacherId)
                .orElseThrow(() -> new BusinessException(404, "课程不存在或无权操作"));

        // 验证权重总和=1
        BigDecimal total = weights.stream()
                .map(GradeWeightDTO::getWeight)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (total.compareTo(BigDecimal.ONE) != 0) {
            throw new BusinessException(400, "权重总和必须等于100%");
        }

        // 删除旧配置
        weightRepo.deleteByCourseId(courseId);

        // 保存新配置
        List<GradeWeight> entities = weights.stream()
                .map(dto -> new GradeWeight(null, course, dto.getItemName(), dto.getWeight(), teacherId, null))
                .toList();
        weightRepo.saveAll(entities);
    }

    /**
     * 获取课程的分数比重配置
     */
    public List<GradeWeightDTO> getGradeWeights(Long courseId) {
        return weightRepo.findByCourseId(courseId)
                .stream()
                .map(w -> new GradeWeightDTO(w.getItemName(), w.getWeight()))
                .toList();
    }
    @Cacheable(value = "studentGrades", key = "#studentId")
    public List<Grade> getGrades(String studentId) {
        return gradeRepository.findByStudentId(studentId);
    }
}
